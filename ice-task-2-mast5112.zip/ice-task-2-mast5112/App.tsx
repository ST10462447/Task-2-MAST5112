import React, { useState, useEffect } from 'react';
import { View, 
         Text, 
         Button, 
         TextInput, 
         StyleSheet 
        } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';

const difficulties = {
  Apprentice: { time: 30, range: 10 },
  Wizard: { time: 20, range: 20 },
  Sorcerer: { time: 10, range: 50 },
};

const App = () => {
  const [screen, setScreen] = useState<'home' | 'game' | 'result'>('home');
  const [score, setScore] = useState(0);
  const [difficulty, setDifficulty] = useState('Apprentice');
  const [equation, setEquation] = useState('');
  const [answer, setAnswer] = useState('');
  const [timeLeft, setTimeLeft] = useState(difficulties[difficulty].time);
  const [isGameOver, setIsGameOver] = useState(false);
  const [powerUpUsed, setPowerUpUsed] = useState(false);

  useEffect(() => {
    let timer: NodeJS.Timeout;
    if (screen === 'game' && timeLeft > 0) {
      timer = setInterval(() => {
        setTimeLeft(timeLeft - 1);
      }, 1000);
    } else if (timeLeft === 0) {
      endGame();
    }
    return () => clearInterval(timer);
  }, [timeLeft, screen]);

  const startGame = () => {
    setScore(0);
    setTimeLeft(difficulties[difficulty].time);
    generateEquation();
    setScreen('game');
    setPowerUpUsed(false);
  };

  const generateEquation = () => {
    const range = difficulties[difficulty].range;
    const num1 = Math.floor(Math.random() * range) + 1;
    const num2 = Math.floor(Math.random() * range) + 1;
    const operations = ['+', '-', '*', '/'];
    const operation = operations[Math.floor(Math.random() * operations.length)];
    setEquation(`${num1} ${operation} ${num2}`);
  };

  const checkAnswer = () => {
    const correctAnswer = eval(equation);
    if (parseFloat(answer) === correctAnswer) {
      setScore(score + 10);
      setTimeLeft(timeLeft + 5); 
      generateEquation();
    } else {
      setScore(score - 5);
    }
    setAnswer(''); 
  };

  const usePowerUp = () => {
    if (!powerUpUsed) {
      setTimeLeft(timeLeft + 10); 
      setPowerUpUsed(true); 
    }
  };

  const endGame = () => {
    setIsGameOver(true);
    saveHighScore(score);
    setScreen('result');
  };

  const resetGame = () => {
    setScreen('home');
    setIsGameOver(false);
    setAnswer('');
  };

  const saveHighScore = async (score: number) => {
    try {
      const highScores = JSON.parse(await AsyncStorage.getItem('highScores')) || [];
      highScores.push(score);
      highScores.sort((a: number, b: number) => b - a);
      await AsyncStorage.setItem('highScores', JSON.stringify(highScores.slice(0, 5))); 
    } catch (error) {
      console.error('Error saving high scores:', error);
    }
  };

  const selectDifficulty = (level: 'Apprentice' | 'Wizard' | 'Sorcerer') => {
    setDifficulty(level);
    startGame();
  };

  return (
    <View style={styles.container}>
      {screen === 'home' && (
        <View style={styles.homeScreen}>
          <Text style={styles.title}>Welcome to Arithmetica's Quest!</Text>
          <Text>Help Arithmetica pass her math exam by solving magical problems.</Text>
          <Button title="Start Training" onPress={startGame} />
          <Text>Select Difficulty:</Text>
          <Button title="Apprentice" onPress={() => selectDifficulty('Apprentice')} />
          <Button title="Wizard" onPress={() => selectDifficulty('Wizard')} />
          <Button title="Sorcerer" onPress={() => selectDifficulty('Sorcerer')} />
        </View>
      )}

      {screen === 'game' && (
        <View style={styles.gameScreen}>
          <Text>Scenario: Arithmetica needs your help to cast a spell!</Text>
          <Text>Equation: {equation}</Text>
          <TextInput
            style={styles.input}
            keyboardType="numeric"
            value={answer}
            onChangeText={setAnswer}
            placeholder="Enter your answer"
          />
          <Button title="Submit" onPress={checkAnswer} />
          <Text>Time left: {timeLeft} seconds</Text>
          <Text>Score: {score}</Text>
          <Button title="Use Time Warp" onPress={usePowerUp} disabled={powerUpUsed} />
        </View>
      )}

      {screen === 'result' && (
        <View style={styles.resultScreen}>
          <Text>Training Results</Text>
          <Text>Final Score: {score}</Text>
          <Button title="Continue Training" onPress={resetGame} />
        </View>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 16,
    backgroundColor: '#ffc0cb',
  },
  homeScreen: {
    alignItems: 'center',
  },
  gameScreen: {
    alignItems: 'center',
  },
  resultScreen: {
    alignItems: 'center',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
  },
  input: {
    height: 40,
    borderColor: 'gray',
    borderWidth: 1,
    width: '80%',
    marginBottom: 10,
    textAlign: 'center',
  },
});

export default App;
